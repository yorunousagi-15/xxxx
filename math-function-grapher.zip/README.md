# Math Graph Studio

数式を入力して2次元グラフを描画する、GitHub Pages向けの静的Webアプリです。

## 公開方法

1. この3ファイルをGitHubリポジトリにアップロード
2. `Settings` → `Pages`
3. `Deploy from a branch`
4. `main` / `/ (root)` を選択
5. Save

数分後にGitHub Pagesで公開できます。

## 使用ライブラリ

- math.js: 数式の解析・数値計算
- Plotly.js: グラフ描画

どちらもCDNから読み込むため、ビルド環境は不要です。

## 入力例

```text
x^2
x^3 + 2*x
sin(x)
cos(x)
tan(x)
asin(x)
acos(x)
atan(x)
e^x
exp(-x^2)
ln(x)
log10(x)
log(x,10)
sqrt(x)
abs(x)
floor(x)
ceil(x)
factorial(x)
x!
gamma(x)
```

三角関数はラジアンです。

const COLORS = [
  "#175CD3", "#D92D20", "#039855", "#7F56D9",
  "#DC6803", "#0E9384", "#C11574", "#344054"
];

const list = document.getElementById("functionList");
const statusEl = document.getElementById("status");
let rows = [];

function setStatus(text, error = false) {
  statusEl.textContent = text;
  statusEl.style.background = error ? "#fff0f0" : "#f2f4f7";
  statusEl.style.color = error ? "#b42318" : "#475467";
}

function normalizeExpression(raw) {
  let s = raw.trim();
  if (!s) return "";
  s = s.replace(/^y\s*=\s*/i, "");
  s = s.replace(/π/g, "pi");
  s = s.replace(/√\s*\(/g, "sqrt(");
  s = s.replace(/√\s*([A-Za-z0-9.]+)/g, "sqrt($1)");
  return s;
}

function addRow(value = "") {
  const id = crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random());
  const index = rows.length;
  rows.push(id);

  const row = document.createElement("div");
  row.className = "function-row";
  row.dataset.id = id;
  row.innerHTML = `
    <div class="row-head">
      <span class="color-dot" style="background:${COLORS[index % COLORS.length]}"></span>
      <strong>f${index + 1}(x)</strong>
      <button class="delete" title="削除">削除</button>
    </div>
    <input class="expr" spellcheck="false" placeholder="例: x^2 + sin(x)" value="${escapeHtml(value)}">
  `;

  row.querySelector(".delete").addEventListener("click", () => {
    rows = rows.filter(x => x !== id);
    row.remove();
    if (!list.children.length) addRow("x^2");
    draw();
  });

  row.querySelector(".expr").addEventListener("input", debounce(draw, 180));
  row.querySelector(".expr").addEventListener("keydown", e => {
    if (e.key === "Enter") draw();
  });

  list.appendChild(row);
}

function escapeHtml(value) {
  return value.replaceAll("&","&amp;").replaceAll("<","&lt;")
    .replaceAll(">","&gt;").replaceAll('"',"&quot;");
}

function debounce(fn, ms) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

function makeX(min, max, count) {
  const step = (max - min) / (count - 1);
  return Array.from({length: count}, (_, i) => min + i * step);
}

function evaluate(expr, x) {
  // math.js scope gives users x, pi and e.
  // factorial(x) and gamma(x) are supplied by math.js.
  return math.evaluate(expr, {x, pi: Math.PI, e: Math.E});
}

function draw() {
  const xmin = Number(document.getElementById("xmin").value);
  const xmax = Number(document.getElementById("xmax").value);
  let count = Number(document.getElementById("samples").value);

  if (!Number.isFinite(xmin) || !Number.isFinite(xmax) || xmin >= xmax) {
    setStatus("x範囲を正しく入力してください。", true);
    return;
  }

  count = Math.max(100, Math.min(10000, Math.floor(count)));
  const xs = makeX(xmin, xmax, count);
  const traces = [];
  let errors = 0;

  document.querySelectorAll(".function-row").forEach((row, i) => {
    const raw = row.querySelector(".expr").value;
    const expr = normalizeExpression(raw);
    if (!expr) return;

    const ys = [];
    for (const x of xs) {
      try {
        const value = evaluate(expr, x);
        let y = typeof value === "number" ? value : Number(value);
        if (!Number.isFinite(y) || Math.abs(y) > 1e12) {
          ys.push(null);
        } else {
          ys.push(y);
        }
      } catch {
        ys.push(null);
      }
    }

    if (ys.some(v => v !== null)) {
      traces.push({
        x: xs,
        y: ys,
        type: "scatter",
        mode: "lines",
        name: raw || `f${i+1}(x)`,
        line: {width: 2, color: COLORS[i % COLORS.length]},
        connectgaps: false
      });
    } else {
      errors++;
    }
  });

  const layout = {
    margin: {l: 55, r: 25, t: 35, b: 50},
    paper_bgcolor: "#ffffff",
    plot_bgcolor: "#ffffff",
    hovermode: "x unified",
    xaxis: {
      title: "x",
      zeroline: true,
      gridcolor: "#eaecf0"
    },
    yaxis: {
      title: "y",
      zeroline: true,
      gridcolor: "#eaecf0"
    },
    legend: {orientation: "h", y: 1.04, x: 0},
    font: {family: "system-ui, sans-serif", color: "#344054"}
  };

  Plotly.react("graph", traces, layout, {
    responsive: true,
    displaylogo: false,
    modeBarButtonsToRemove: ["lasso2d", "select2d"]
  });

  setStatus(errors ? `${traces.length}本を描画。式を確認できない関数があります。` : `${traces.length}本の関数を描画しました。`);
}

document.getElementById("addBtn").addEventListener("click", () => {
  addRow("");
});

document.getElementById("resetBtn").addEventListener("click", () => {
  document.getElementById("xmin").value = -10;
  document.getElementById("xmax").value = 10;
  document.getElementById("samples").value = 1800;
  draw();
  const graph = document.getElementById("graph");
  Plotly.relayout(graph, {"xaxis.autorange": true, "yaxis.autorange": true});
});

document.getElementById("sampleBtn").addEventListener("click", () => {
  list.innerHTML = "";
  rows = [];
  addRow("x^2");
  addRow("2*sin(x)");
  addRow("exp(-x^2)");
  draw();
});

["xmin", "xmax", "samples"].forEach(id => {
  document.getElementById(id).addEventListener("input", debounce(draw, 180));
});

addRow("x^2");
addRow("sin(x)");
draw();
